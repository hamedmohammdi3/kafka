package com.thecodinginterface.avropeopleconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvroPeopleConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvroPeopleConsumerApplication.class, args);
	}

}
