package com.thecodinginterface.peopleconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PeopleConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PeopleConsumerApplication.class, args);
	}

}
