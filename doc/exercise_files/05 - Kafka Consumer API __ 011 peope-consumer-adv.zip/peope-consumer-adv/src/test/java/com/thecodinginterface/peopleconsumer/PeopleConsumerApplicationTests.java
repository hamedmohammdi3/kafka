package com.thecodinginterface.peopleconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeopleConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
