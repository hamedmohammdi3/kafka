
person_value_v1 = """
  {
    "namespace": "com.thecodinginterface.avrodomainevents",
    "name": "Person",
    "type": "record",
    "fields": [
      {
        "name": "name",
        "type": "string"
      },
      {
        "name": "title",
        "type": "string"
      }
    ]
  }
"""
