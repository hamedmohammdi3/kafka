package com.thecodinginterface.peopleservicebasic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PeopleServiceBasicApplication {

	public static void main(String[] args) {
		SpringApplication.run(PeopleServiceBasicApplication.class, args);
	}

}
