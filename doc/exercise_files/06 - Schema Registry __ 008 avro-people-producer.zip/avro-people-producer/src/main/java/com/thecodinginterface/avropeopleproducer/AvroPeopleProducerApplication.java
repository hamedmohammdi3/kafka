package com.thecodinginterface.avropeopleproducer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvroPeopleProducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvroPeopleProducerApplication.class, args);
	}

}
